<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    
                <div class="card mt-4">
                    <div class="card-header"><?php echo e(trans('app.Posts')); ?></div>

                    <div class="card-body">
                        <table class="table table-bordered mb-0">
                            <thead>
                            <tr>
                                <th scope="col" width="200"><?php echo e(trans('app.Title')); ?></th>
                                <th scope="col" width="200"><?php echo e(trans('app.creat')); ?></th>
                                <th scope="col" width="200"><?php echo e(trans('app.Action')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                           <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                    <td><?php echo e($post->id); ?></td>
                                    <td><?php echo e(App::isLocale('ar') ? $post->ar_title: $post->en_title); ?></td>
                                    <td><?php echo e($post->user->name); ?></td>
                                    
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>

              
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Pictures\DB\laravel-7\resources\views/admin/index.blade.php ENDPATH**/ ?>