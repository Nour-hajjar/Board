


<?php $__env->startSection('content'); ?>
<div class="card-body">
<div class="row">
    <div class="col-lg-12 margin-tb">
        <div class="pull-left">
            <h2 style="text-align: center;">             <?php echo e(trans('app.info')); ?></h2>
        </div>
     
    </div>
</div>


<table class="table" style="width: 90%;margin:5%;margin-top: 2%">   
  <tbody class="thead-light">
    <tr>
      <th scope="row" style="width:10%"><?php echo e(trans('app.en_name')); ?></th>
      <td><?php echo e($info->en_name); ?></td>
    </tr>
    <tr>
      <th scope="row"><?php echo e(trans('app.ar_name')); ?></th>
      <td><?php echo e($info->ar_name); ?></td>
    </tr>
        <tr>
      <th scope="row"><?php echo e(trans('app.namee')); ?></th>
      <td><?php echo e($info->name); ?></td>
    </tr>
    <tr>
      <th scope="row"><?php echo e(trans('app.namee_a')); ?></th>
      <td><?php echo e($info->name_a); ?></td>
    </tr>    
  <tr>
      <th scope="row"><?php echo e(trans('app.en_course')); ?></th>
      <td><?php echo e($info->en_course); ?></td>
    </tr> 
      <tr>
      <th scope="row"><?php echo e(trans('app.ar_course')); ?></th>
      <td><?php echo e($info->ar_course); ?></td>
    </tr>
      <tr>
      <th scope="row"><?php echo e(trans('app.code')); ?></th>
      <td><?php echo e($info->code); ?></td>
    </tr>
  <tr>
      <th scope="row"><?php echo e(trans('app.date')); ?></th>
      <td><?php echo e($info->date); ?></td>
    </tr>
  </tbody>
</table>

        <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
            <a class="btn btn-primary col-sm-12" href="<?php echo e(route('infos.index')); ?>"><?php echo e(trans('app.Back')); ?> </a>
        </div>
        <div class="col-sm-4"></div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Noara\Desktop\INTBD\laravel-7\laravel-7\resources\views/admin/info/show.blade.php ENDPATH**/ ?>