<?php $__env->startSection('content'); ?>
    <!-- Page Header -->

  <body>
    
        <header id="masthead" class="site-header">
        <nav id="primary-navigation" class="site-navigation">
            <div class="container">

                <div class="navbar-header">

                    <a class="site-title"><span>International Board</span> of professional training and Qualification</a>

                </div>
                <!-- /.navbar-header -->

                <div class="collapse navbar-collapse" id="agency-navbar-collapse">

                    <ul class="nav navbar-nav navbar-right">

                        <li class="active"><a href="index.html" data-toggle="dropdown">الرئيسية</a></li>

                        <li><a href="portfolio.html">معلومات الشهادة</a></li>
                        <li><a href="ui-elements.html">حول</a></li>
                        <li><a href="blog.html">فريقنا المميز</a></li>
                        <li><a href="contact.html">الاتصال بنا</a></li>


                    </ul>

                </div>

            </div>
        </nav>
        <!-- /.site-navigation -->
    </header>
    <!-- /#mastheaed -->

    <div id="hero" class="hero overlay">
        <div class="hero-content">
            <div class="hero-text">
                <h1>البورد الدولي للتدريب والتأهيل </h1>
                <p>للتأكد من ثبوتية الشهادة الرجاء أدخل الكود هنا</p>
                <a href="#" class="btn btn-border">أدخل الكود</a>
            </div>
            <!-- /.hero-text -->
        </div>
        <!-- /.hero-content -->
    </div>
    <!-- /.hero -->

    <main id="main" class="site-main">

        <section class="site-section section-features">
            <div class="container">
                <div class="row">
                    <div class="col-sm-5">
                        <h2> International Board of professional training and Qualification </h2>

                    </div>
                    <div class="col-sm-7 hidden-xs">
                        <img src="assets/img/ipad-pro.png" alt="">
                    </div>
                </div>
            </div>
        </section>
        <!-- /.section-features -->

        <section class="site-section section-services gray-bg text-center">
            <div class="container">
                <h2 class="heading-separator"> شركاء النجاح في البورد الدولي للتدريب والتأهيل </h2>
                <p class="subheading-text">نتوجه بالشكر لجميع الشركات والمؤسسات الداعمة لأفكارنا التنموية</p>
                <div class="row">
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/1.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">أعمالكم للخدمات اللوجستية</h3>
                            <p class="service-info"></p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/2.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">الخارجية البريطانية</h3>
                            <p class="service-info"> </p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/3.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">أكاديمية ابن حزم</h3>
                            <p class="service-info"></p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/4.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">Arab British</h3>
                            <p class="service-info"></p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/5.png" alt="" height="175" width="175">
                            <h3 class="service-title">Support</h3>
                            <p class="service-info">A support network can include a variety of forms of interaction with a range of people who can support you in different ways. </p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/a1.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">Support</h3>
                            <p class="service-info">A support network can include a variety of forms of interaction with a range of people who can support you in different ways. </p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/a2.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">Support</h3>
                            <p class="service-info">A support network can include a variety of forms of interaction with a range of people who can support you in different ways. </p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/a3.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">Support</h3>
                            <p class="service-info">A support network can include a variety of forms of interaction with a range of people who can support you in different ways. </p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/a4.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">Support</h3>
                            <p class="service-info">A support network can include a variety of forms of interaction with a range of people who can support you in different ways. </p>
                        </div>
                        <!-- /.service -->
                    </div>
                    <div class="col-md-3 col-xs-6">
                        <div class="service">
                            <img src="assets/img/a5.jpg" alt="" height="175" width="175">
                            <h3 class="service-title">Support</h3>
                            <p class="service-info">A support network can include a variety of forms of interaction with a range of people who can support you in different ways. </p>
                        </div>
                        <!-- /.service -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.section-services -->

        <section class="site-section section-map-feature text-center">

            <div class="container">
                <h2> International Board of professional training and Qualification </h2>
                <p></p>
                <!-- <a href="#" class="btn btn-fill">Learn More</a> -->
                <div class="row">
                    <div class="col-sm-3 col-xs-6">
                        <div class="counter-item">
                            <p class="counter" data-to="377" data-speed="2000">0</p>
                            <h3>Cofee Cups</h3>
                        </div>
                        <!-- /.counter-item -->
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counter-item">
                            <p class="counter" data-to="1204" data-speed="2000">0</p>
                            <h3>Projects completed</h3>
                        </div>
                        <!-- /.counter-item -->
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counter-item">
                            <p class="counter" data-to="459" data-speed="1000">0</p>
                            <h3>Happy Clients</h3>
                        </div>
                        <!-- /.counter-item -->
                    </div>
                    <div class="col-sm-3 col-xs-6">
                        <div class="counter-item">
                            <p class="counter" data-to="675" data-speed="1000">0</p>
                            <h3>Average Deal</h3>
                        </div>
                        <!-- /.counter-item -->
                    </div>
                </div>
            </div>

        </section>
        <!-- /.section-map-feature -->

        <section class="site-section section-portfolio">
            <div class="container">
                <div class="text-center">
                    <h2 class="heading-separator"> شركاء النجاح في البورد الدولي للتدريب والتأهيل </h2>
                    <!-- <p class="subheading-text">This is some of our best work</p> -->
                </div>
                <div class="row">
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/a1.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/a2.jpg" class="img-res" alt="" height="10" width="10">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/a3.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/a4.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/a5.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/1.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/2.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/3.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/4.jpg" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                    <div class="col-lg-3 col-md-4 col-xs-6">
                        <div class="portfolio-item">
                            <img src="assets/img/5.png" class="img-res" alt="">
                            <h4 class="portfolio-item-title"> تفاصيل </h4>
                            <!-- <a href="portfolio-item.html"><i class="fa fa-arrow-right" aria-hidden="true"></i></a> -->
                        </div>
                        <!-- /.portfolio-item -->
                    </div>
                </div>
            </div>
        </section>
        <!-- /.section-portfolio -->

        <section class="site-section section-newsletter text-center">
            <div class="container">
                <h2>Subscribe our newsletters</h2>
                <form class="form-group newsletter-group">
                    <input type="email" class="form-control" placeholder="Your e-mail" required>
                    <button class="btn btn-green" type="button">Subscribe</button>
                </form>
                <!-- /.newsletter-group -->
            </div>
        </section>
        <!-- /.section-newsletter -->

    </main>
     <?php $__env->stopSection(); ?>




     
        

<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Noara\Desktop\laravel-7\laravel-7\resources\views/website/index.blade.php ENDPATH**/ ?>