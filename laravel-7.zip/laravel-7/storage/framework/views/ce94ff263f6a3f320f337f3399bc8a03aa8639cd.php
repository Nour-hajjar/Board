<?php $__env->startSection('content'); ?>
    <!-- Page Header -->

           

    
 <div id="hero" class="hero overlay subpage-hero contact-hero">
        <div class="hero-content">
            <div class="hero-text">
                <h1><?php echo e(trans('app.Contact')); ?></h1>
                <ol class="breadcrumb">
              <!--     <li class="breadcrumb-item"><a href="#"></a></li>
                  <li class="breadcrumb-item active"></li> -->
                </ol>
            </div><!-- /.hero-text -->
        </div><!-- /.hero-content -->
    </div><!-- /.hero -->
    
            <div class="row">
                <div class="col-lg-8 col-md-10 mx-auto">
                   
                </div>
                </article>
  
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session('message')); ?>

                    </div>
                <?php endif; ?>

    <main id="main" class="site-main dd">

        <section class="site-section subpage-site-section section-contact-us dd">

            <div class="container">
                <div class="row">
                    <div class="col-sm-7">
                        <h2><?php echo e(trans('app.Contact form')); ?></h2>
                     <?php echo Form::open(['route' => 'contact.submit']); ?>

                            <div class="row">
                                <div class="col-sm-6">
                                    <div class="form-group">
                                      <label for="name"><?php echo e(trans('app.Name')); ?></label>
                                      <input type="text" class="form-control" id="name">
                                    </div>
                                </div>
                                <div class="col-sm-6">
                                    <div class="form-group">
                                      <label for="email"><?php echo e(trans('app.email')); ?></label>
                                      <input type="email" class="form-control" id="email">
                                    </div>
                                </div>
                            </div>
                            <div class="form-group">
                              <label for="phone"><?php echo e(trans('app.Phone')); ?></label>
                              <input class="form-control" id="subject"></input>
                            </div>
                            <div class="form-group">
                              <label for="message"><?php echo e(trans('app.message')); ?></label>
                              <textarea class="form-control form-control-comment" id="message"></textarea>
                            </div>
                            <div class="text-center">
                                <button class="btn btn-green"><?php echo e(trans('app.Contact')); ?></button>
                            </div>
                     
                <?php echo Form::close(); ?>

                    </div>
                    <div class="col-sm-5">
                        <div class="contact-info">
                            <h2><?php echo e(trans('app.Contact information')); ?></h2>
                            <div class="row">
                                <div class="col-sm-12">
                             
                                    </ul>
                                    <h3><?php echo e(trans('app.email')); ?></h3>
                                    <a href="internationalboardof@gmail.com" target="_blank">internationalboardof@gmail.com</a>
                                    <h3><?php echo e(trans('app.Phone')); ?></h3>
                                    <a href="https://wa.me/message/JMK3GTEVO62UO1" target="_blank">whatsapp</a>
                              
                                </div>
                            </div>
                        </div><!-- /.contact-info -->
                    </div>
                </div>
            </div>
            
        </section><!-- /.section-contact-us -->


<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Pictures\INTBD\14-10\laravel-7\laravel-7\laravel-7\resources\views/website/contact.blade.php ENDPATH**/ ?>