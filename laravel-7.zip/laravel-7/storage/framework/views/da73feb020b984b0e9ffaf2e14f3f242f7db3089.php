

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                   <div class="card-header"><?php echo e(trans('app.slider') .': '. $slider->id); ?>

                       
            <a class="btn btn-sm btn-primary float-right col-sm-2" href="<?php echo e(route('sliders.index')); ?>"><?php echo e(trans('app.Back')); ?> </a></div>

                    <div class="card-body">
                        <?php echo Form::open(['route' => ['sliders.update', $slider->id], 'method' => 'put']); ?>

                        <div class="box-body">
                            <div class="form-group <?php if($errors->has('thumbnail')): ?> has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.Thumbnail')); ?>

                                <?php echo Form::text('thumbnail', $slider->thumbnail, ['class' => 'form-control', 'placeholder' => 'Thumbnail']); ?>

                                <?php if($errors->has('thumbnail')): ?>
                                    <span class="help-block"><?php echo $errors->first('thumbnail'); ?></span><?php endif; ?>
                            </div>

                            <div class="form-group <?php if($errors->has('en_title')): ?> has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.en_title')); ?>

                                <?php echo Form::text('en_title', $slider->en_title, ['class' => 'form-control', 'placeholder' => 'EN_Title']); ?>

                                <?php if($errors->has('en_title')): ?>
                                    <span class="help-block"><?php echo $errors->first('en_title'); ?></span><?php endif; ?>
                            </div>

                            <div class="form-group <?php if($errors->has('ar_title')): ?> has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.ar_title')); ?>

                                <?php echo Form::text('ar_title', $slider->ar_title, ['class' => 'form-control', 'placeholder' => 'AR_Title']); ?>

                                <?php if($errors->has('ar_title')): ?>
                                    <span class="help-block"><?php echo $errors->first('ar_title'); ?></span><?php endif; ?>
                            </div>
                                    <div class="form-group <?php if($errors->has('en_sub_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_sub_title')); ?>

                            <?php echo Form::text('en_sub_title', $slider->en_sub_title, ['class' => 'form-control', 'placeholder' => 'EN_Sub Title']); ?>

                            <?php if($errors->has('en_sub_title')): ?>
                                <span class="help-block"><?php echo $errors->first('en_sub_title'); ?></span><?php endif; ?>
                        </div>
                             <div class="form-group <?php if($errors->has('ar_sub_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_sub_title')); ?>

                            <?php echo Form::text('ar_sub_title', $slider->ar_sub_title, ['class' => 'form-control', 'placeholder' => 'AR_Sub Title']); ?>

                            <?php if($errors->has('ar_sub_title')): ?>
                                <span class="help-block"><?php echo $errors->first('ar_sub_title'); ?></span><?php endif; ?>
                        </div>


                        </div>
                        <div class="box-footer">
                            <?php echo Form::submit(trans('app.Update'),['class' => 'btn btn-sm btn-primary']); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>

 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/admin/slider/edit.blade.php ENDPATH**/ ?>