

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
      <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>"> 
  
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                
          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
                               <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>
<main class="main-content">
        <div class="breadcrumbs">
          <div class="container">
            <a href="#"></a>
            <span></span>
          </div>
        </div>

        <div class="page">
          <div class="container">
            


            <div class="filterable-items">
              <div class="insurance-item filterable-item shopping-center">
                <div class="insurance-content">
                  <div class="insurance-icon"><img src="<?php echo e(asset('website/img/life_insurance_gif.GIF')); ?>" style="height: 120px; width: 200px; border-radius:150px!important"></div>
                  <h3 class="insurance-title"><?php echo e(trans('app.life insurance')); ?></h3>
                  <p>
                    <br>
                  </p>
                  <a href="<?php echo e(url('life')); ?>" class="button"><?php echo e(trans('app.read')); ?></a>
                </div>
              </div>
            

              <div class="insurance-item filterable-item skyscraper">
                <div class="insurance-content">
                  <div class="insurance-icon"><img src="<?php echo e(asset('website/img/icon-5a-gif.GIF')); ?>" style="height: 120px; width: 200px;"></div>
                  <h3 class="insurance-title"><?php echo e(trans('app.fire insurance')); ?></h3>
                  <p>
                    <br>
                  </p>
                  <a href="<?php echo e(url('fire')); ?>" class="button"><?php echo e(trans('app.read')); ?></a>
                </div>
              </div>

              <div class="insurance-item filterable-item apartment">
                <div class="insurance-content">
                  <div class="insurance-icon"><img src="<?php echo e(asset('website/img/rt.GIF')); ?>" style="height: 120px; width: 200px; border-radius:150px!important"></div>
                  <h3 class="insurance-title"><?php echo e(trans('app.Maritime transport risk insurance')); ?></h3>
                  <p>
                    
                  </p>
                  <a href="<?php echo e(url('transport')); ?>" class="button"><?php echo e(trans('app.read')); ?></a>
                </div>
              </div>

              <div class="insurance-item filterable-item shopping-center">
                <div class="insurance-content">
                  <div class="insurance-icon"><img src="<?php echo e(asset('website/img/comp_3.GIF')); ?>" style="height: 120px; width: 200px; border-radius: 100px;"></div>
                  <h3 class="insurance-title"><?php echo e(trans('app.Reinsurance aviation and ship hulls')); ?></h3>
                  <p>
                    
                  </p>
                  <a href="<?php echo e(url('reinsurance')); ?>" class="button"><?php echo e(trans('app.read')); ?></a>
                </div>
              </div>

              <div class="insurance-item filterable-item apartment">
                <div class="insurance-content">
                  <div class="insurance-icon">  <img src="<?php echo e(asset('website/img/car-new.GIF')); ?>" style="height: 120px; width: 200px;"></div>
                  <h3 class="insurance-title"><?php echo e(trans('app.CarsInsurance')); ?></h3>
                  <p>
                    <br>
                  </p>
                  <a href="<?php echo e(url('car')); ?>" class="button"><?php echo e(trans('app.read')); ?></a>
                </div>
              </div>
      <div class="insurance-item filterable-item skyscraper">
                <div class="insurance-content">
                  <div class="insurance-icon"><img src="<?php echo e(asset('website/img/rnm.GIF')); ?>" style="height: 120px; width: 200px; border-radius: 120px;"></div>
                  <h3 class="insurance-title"><?php echo e(trans('app.health insurance')); ?></h3>
                  <p>
                    <br>
                  </p>
                    <a href="<?php echo e(url('insurance')); ?>" class="button"><?php echo e(trans('app.read')); ?></a>
                </div>
              </div>
            </div>
           
            
          </div>
        </div> <!-- .page -->
      </main>

</div>
</body>
   
      <?php $__env->stopSection(); ?>
<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/mainn.blade.php ENDPATH**/ ?>