<!doctype html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport"
          content="width=device-width, user-scalable=no, initial-scale=1.0, maximum-scale=1.0, minimum-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>
<div>
    <p>Name: <?php echo e($data['name']); ?></p>
    <p>Email: <?php echo e($data['email']); ?></p>
    <p>Tel: <?php echo e($data['phone']); ?></p>
    <p>Message: <?php echo e($data['message']); ?></p>
</div>
</body>
</html><?php /**PATH C:\Users\n.hajjar\Pictures\DB\laravel-7\resources\views/admin/email/contact.blade.php ENDPATH**/ ?>