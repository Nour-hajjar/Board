

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
   <?php echo e(trans('app.about') .': '. $about->id); ?>

                       
            <a class="btn btn-sm btn-primary float-right col-sm-2" href="<?php echo e(route('abouts.index')); ?>"><?php echo e(trans('app.Back')); ?> </a>
                        
                    </div>
                    <div class="card-body">
                        <?php echo Form::open(['route' => ['abouts.update', $about->id], 'method' => 'put']); ?>

                        <div class="box-body">
                         

                               <div class="form-group <?php if($errors->has('en_title')): ?> has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.en_title')); ?>

                                <?php echo Form::text('en_title', $about->en_title, ['class' => 'form-control', 'placeholder' => 'EN_Title']); ?>

                                <?php if($errors->has('en_title')): ?>
                                    <span class="help-block"><?php echo $errors->first('en_title'); ?></span><?php endif; ?>
                            </div>
                                <div class="form-group <?php if($errors->has('ar_title1')): ?> has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.ar_title')); ?>

                                <?php echo Form::text('ar_title', $about->ar_title, ['class' => 'form-control', 'placeholder' => 'AR_Title']); ?>

                                <?php if($errors->has('ar_title')): ?>
                                    <span class="help-block"><?php echo $errors->first('ar_title'); ?></span><?php endif; ?>
                            </div>


<div class="form-group <?php if($errors->has('en_details')): ?>
                             has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.en_details')); ?>

                                <?php echo Form::textarea('en_details', $about->en_details, ['class' => 'form-control', 'placeholder' => 'Details']); ?>

                                <?php if($errors->has('en_details')): ?>
                                    <span class="help-block"><?php echo $errors->first('en_details'); ?></span><?php endif; ?>
                            </div>
                                 <div class="form-group <?php if($errors->has('ar_details')): ?>
                             has-error <?php endif; ?>">
                                <?php echo Form::label(trans('app.ar_details')); ?>

                                <?php echo Form::textarea('ar_details', $about->ar_details, ['class' => 'form-control', 'placeholder' => 'Details2']); ?>

                                <?php if($errors->has('ar_details')): ?>
                                    <span class="help-block"><?php echo $errors->first('ar_details'); ?></span><?php endif; ?>
                            </div>

                        </div>
                        <div class="box-footer">
                            <?php echo Form::submit(trans('app.edit'),['class' => 'btn btn-sm btn-primary']); ?>

                        </div>
                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js" integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>


     <script>
        $(document).ready(function () {
       
            CKEDITOR.replace('en_details', {
            removePlugins: 'sourcearea'
        });
            CKEDITOR.replace('ar_details', {
            removePlugins: 'sourcearea'
        });

               });
    </script>
 
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Pictures\DB\laravel-7\resources\views/admin/about/edit.blade.php ENDPATH**/ ?>