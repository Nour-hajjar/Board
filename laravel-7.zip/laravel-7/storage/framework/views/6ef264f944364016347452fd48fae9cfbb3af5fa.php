


<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-lg-12 margin-tb" style="margin-top: 5%">
        <div class="pull-left">
            <h2 style="text-align: center;"><?php echo e(trans('app.Category')); ?></h2>
        </div>

    </div>
</div>
<table class="table" style="width: 90%;margin:5%;margin-top: 2%">   
  <tbody class="thead-light">
    <tr>
      <th scope="row" style="width:10%"><?php echo e(trans('app.Thumbnail')); ?></th>
      <td><?php echo e($category->thumbnail); ?></td>
    </tr>
   <tr>
      <th scope="row"><?php echo e(trans('app.name_a')); ?></th>
      <td><?php echo e($category->name_a); ?></td>
    </tr>
       <tr>
      <th scope="row"><?php echo e(trans('app.name')); ?></th>
      <td><?php echo e($category->name); ?></td>
    </tr>
     </tbody>
</table>

        <div class="row">
        <div class="col-sm-4"></div>
        <div class="col-sm-4">
            <a class="btn btn-primary col-sm-12" href="<?php echo e(route('categories.index')); ?>"><?php echo e(trans('app.Back')); ?> </a>
        </div>
        <div class="col-sm-4"></div>
        </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/admin/category/show.blade.php ENDPATH**/ ?>