<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                                            <div class="card-header">
     <?php echo e(trans('app.Category') .': '. $category->id); ?>

                       
            <a class="btn btn-sm btn-primary float-right col-sm-2" href="<?php echo e(route('categories.index')); ?>"><?php echo e(trans('app.Back')); ?> </a>

                    <div class="card-body">
                        <?php echo Form::open(['route' => ['categories.update', $category->id], 'method' => 'put']); ?>

                        <div class="form-group <?php if($errors->has('thumbnail')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.Thumbnail')); ?>

                            <?php echo Form::text('thumbnail', $category->thumbnail, ['class' => 'form-control', 'placeholder' => 'Thumbnail']); ?>

                            <?php if($errors->has('thumbnail')): ?>
                                <span class="help-block"><?php echo $errors->first('thumbnail'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.name')); ?>

                            <?php echo Form::text('name', $category->name, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block"><?php echo $errors->first('name'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('name_a')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.name_a')); ?>

                            <?php echo Form::text('name_a', $category->name_a, ['class' => 'form-control', 'placeholder' => 'name_a']); ?>

                            <?php if($errors->has('name_a')): ?>
                                <span class="help-block"><?php echo $errors->first('name_a'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label(trans('app.Publish')); ?>

                            <?php echo Form::select('is_published', [1 => 'Publish', 0 => 'Draft'], isset($category->is_published) ? $category->is_published : null, ['class' => 'form-control']); ?>

                        </div>

                        <?php echo Form::submit(trans('app.Update'),['class' => 'btn btn-sm btn-warning']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Noara\Desktop\INTBD\laravel-7\laravel-7\resources\views/admin/category/edit.blade.php ENDPATH**/ ?>