<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
  <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>"> 
       
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                
          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
                               <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>
                        <article>
            <div class="row">
                <div class="col-lg-8 col-md-10 mx-auto">
                   
                </div>
                </article>
  
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session('message')); ?>

                    </div>
                <?php endif; ?>
            <!-- Contact Form - Enter your email address on line 19 of the mail/contact_me.php file to make this form work. -->
                <!-- WARNING: Some web hosts do not allow emails to be sent through forms to common mail hosts like Gmail or Yahoo. It's recommended that you use a private domain email address! -->
                <!-- To use the contact form, your site must be on a live web host with PHP! The form will not work locally! -->
                          <main class="main-content">
                <div class="breadcrumbs">
                    <div class="container">
                     <!--    <a href="index.html">Home</a>
                        <span>Contact</span> -->
                    </div>
                </div>


                <div class="page">

                    <div class="container">
                        <div id="s5_component_wrap">
                        <div id="s5_component_wrap_inner">

                            
                                                            <main>
                                <div id="system-message-container">
    </div>

<div class="item-page" itemscope="" itemtype="https://schema.org/Article">
    <meta itemprop="inLanguage" content="ar-AA">
    
        
            <div class="page-header">
                    <h2 itemprop="headline" style="text-align: center;">
                <?php echo e(trans('app.contact information')); ?>      </h2>
                                    </div>
                    
        
    
    
        
                                <div itemprop="articleBody">
        <center>
<div class="table-responsive">
<p style="text-align: center;">&nbsp;</p>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="text-align: center;"><?php echo e(trans('app.place')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.governorate')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.addressss')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.number')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.fax')); ?></th>
        </tr>
    </thead>
    <tbody>
        <tr>
            <td><?php echo e(trans('app.general_ administration')); ?> </td>
            <td><?php echo e(trans('app.homs')); ?> </td>
            <td><?php echo e(trans('app.city_center')); ?></td>
            <td>2451181</td>
            <td>2451183</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?> </td>
            <td><?php echo e(trans('app.homs')); ?></td>
            <td><?php echo e(trans('app.homs_City')); ?></td>
            <td>2477704</td>
            <td>2469972</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?></td>
            <td><?php echo e(trans('app.damascus')); ?></td>
            <td><?php echo e(trans('app.addresss')); ?></td>
            <td>2226669-2229996</td>
            <td>2244060</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office_ managers')); ?></td>
            <td><?php echo e(trans('app.damascus')); ?></td>
            <td><?php echo e(trans('app.may_street')); ?></td>
            <td>2330334</td>
            <td>2330331</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?> </td>
            <td><?php echo e(trans('app.aleppo')); ?></td>
            <td><?php echo e(trans('app.bahrat_square')); ?></td>
            <td>2112032-2112038-2112041</td>
            <td>2112041</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?> </td>
            <td><?php echo e(trans('app.hama')); ?></td>
            <td><?php echo e(trans('app.castle_side')); ?></td>
            <td>2537551</td>
            <td>2537500</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?> </td>
            <td><?php echo e(trans('app.al_hasakah')); ?></td>
            <td><?php echo e(trans('app.palestine_street')); ?></td>
            <td>321387</td>
            <td>321370</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?> </td>
            <td><?php echo e(trans('app.der_alzoor')); ?></td>
            <td><?php echo e(trans('app.hamoud_al_abed')); ?></td>
            <td>326928</td>
            <td>326929</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?></td>
            <td><?php echo e(trans('app.tartous')); ?></td>
            <td><?php echo e(trans('app.al_mina_street')); ?></td>
            <td>319187</td>
            <td>315143</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?></td>
            <td><?php echo e(trans('app.latakia')); ?></td>
            <td><?php echo e(trans('app.saliba')); ?></td>
            <td>465284</td>
            <td>465042</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?></td>
            <td><?php echo e(trans('app.daraa')); ?></td>
            <td><?php echo e(trans('app.daraa_governorate')); ?></td>
            <td>236691</td>
            <td>236691</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.branch')); ?></td>
            <td><?php echo e(trans('app.sweida')); ?></td>
            <td><?php echo e(trans('app.central_market')); ?></td>
            <td>227799</td>
            <td>234925</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office')); ?></td>
            <td><?php echo e(trans('app.masyaf')); ?></td>
            <td><?php echo e(trans('app.warraqa')); ?></td>
            <td>7711727</td>
            <td>7711727</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office')); ?></td>
            <td><?php echo e(trans('app.mhardeh')); ?></td>
            <td><?php echo e(trans('app.main_square')); ?></td>
            <td>4733276</td>
            <td>4733276</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office')); ?></td>
            <td><?php echo e(trans('app.al_silmiya')); ?></td>
            <td><?php echo e(trans('app.guards_school')); ?></td>
            <td>8812490</td>
            <td>8812490</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office')); ?></td>
            <td><?php echo e(trans('app.baniyas')); ?></td>
            <td><?php echo e(trans('app.corniche_street')); ?></td>
            <td>710256</td>
            <td>710256</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office')); ?></td>
            <td><?php echo e(trans('app.jableh')); ?></td>
            <td><?php echo e(trans('app.ibrahim_mosque')); ?></td>
            <td>830404</td>
            <td>830404</td>
        </tr>
        <tr>
            <td><?php echo e(trans('app.office')); ?></td>
            <td><?php echo e(trans('app.al-qamishli')); ?></td>
            <td><?php echo e(trans('app.al_wahda')); ?></td>
            <td>429895</td>
            <td>429895</td>
        </tr>
    </tbody>
</table>
</div>
</center>
    </div>

    
                            </div>

                                <div style="clear:both;height:0px"></div>
                                </main>
                            
                            
                        </div>
                        </div>
                        <br>
                        <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3326.384000748498!2d36.297580885377066!3d33.517400453173245!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1518e730265bdba5%3A0x95d4f4273fc7f51d!2z2KfZhNmF2KTYs9iz2Kkg2KfZhNi52KfZhdipINin2YTYs9mI2LHZitipINmE2YTYqtij2YXZitmG!5e0!3m2!1sar!2s!4v1656255716012!5m2!1sar!2s" width="1100" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>

                        <div class="row">
                            <div class="col-md-3">
                                <h2 class="section-title text-left ltr"><?php echo e(trans('app.address')); ?></h2>

                                <div class="contact-detail ltr"  style=" font-weight: bold">
                                    <address>
                                        <p><?php echo e(trans('app.Headquarters: Mohandessin Building, Bab Hood, Homs')); ?>

                                            <br>
<?php echo e(trans('app.Temporary')); ?><br>
<?php echo e(trans('app.General Administration')); ?>

                                            </p>

                                    
                                    </address>
                                </div>
                            </div>

                            <div class="col-md-9">
                                <h2 class="section-title text-left ltr"><?php echo e(trans('app.Contact form')); ?></h2>
                                    <?php echo Form::open(['route' => 'contact.submit']); ?>


                                <form action="#" class="contact-form">
                                    <div class="row ltr">
                                        <div class="col-md-4"><input type="text" id="name" placeholder="<?php echo e(trans('app.Name')); ?>"></div>
                                        <div class="col-md-4"><input type="email" placeholder="<?php echo e(trans('app.email')); ?>"></div>
                                        <div class="col-md-4"><input id="phone" type="text" placeholder="<?php echo e(trans('app.Phone')); ?>" id="message" required
                                                  data-validation-required-message="Please enter a message"></div>
                                    </div>

                                    <textarea  placeholder="<?php echo e(trans('app.message')); ?>"></textarea>

                                    <p class="text-right">
                                        <input type="submit" value="<?php echo e(trans('app.Send message')); ?>">
                                    </p>
                                </form>


                <?php echo Form::close(); ?>

                            </div>
                        </div>
                    </div>
                </div> <!-- .page -->

            </main>

          </div>
      </article>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/contact.blade.php ENDPATH**/ ?>