<?php $__env->startSection('content'); ?>
    <!-- Page Header -->

  <body>
    
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                
          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
                               <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>
            <!-- .site-header -->

            <div class="hero hero-slider">
                <ul class="slides">
                       <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $slider): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li data-bg-image="<?php echo e(route('getImage',$slider->thumbnail)); ?>">
                        <div class="container" style="direction: rtl!important">
                            <div class="slide-content" >
                                <h2 class="slide-title ltr" > <?php echo e(App::isLocale('ar') ? $slider->ar_title: $slider->en_title); ?></h2>
                                <p class="ltr"><?php echo e(App::isLocale('ar') ? $slider->ar_sub_title: $slider->en_sub_title); ?></p>
                                <a href="#" class="button"><?php echo e(trans('app.read')); ?></a>
                            </div>
                        </div>
                    </li>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <!--   <li data-bg-image="<?php echo e(asset('website/dummy/slide-2.jpg')); ?>">
                        <div class="container">
                            <div class="slide-content">
                                <h2 class="slide-title">Get your <strong>Life Insurance</strong></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus quos cumque odio soluta harum error sequi laudantium, est nam perspiciatis eveniet maxime, esse possimus architecto sunt natus reprehenderit debitis fugit.</p>
                                <a href="#" class="button">Get a quote</a>
                            </div>
                        </div>
                    </li>
                    <li data-bg-image="<?php echo e(asset('website/dummy/slide-3.jpg')); ?>">
                        <div class="container">
                            <div class="slide-content">
                                <h2 class="slide-title">Get your <strong>Life Insurance</strong></h2>
                                <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Repellendus quos cumque odio soluta harum error sequi laudantium, est nam perspiciatis eveniet maxime, esse possimus architecto sunt natus reprehenderit debitis fugit.</p>
                                <a href="#" class="button">Get a quote</a>
                            </div>
                        </div>
                    </li> -->
                </ul>
            </div> <!-- .hero-slider -->
<div class="container-fluid  p-0 m-0 ">
    <div class="row" style="direction: rtl!important;">
        <div class="col-md-12">
            <div class="d-flex justify-content-between align-items-center breaking-news bg-white  ">
                <button type="button" class=" bg-danger  position-relative" style="width: 200px; height: 50px; background-color: #0f75bd!important; color:white; font-weight: bold;">
                    <?php echo e(trans('app.latest')); ?>


                  </button>

                <marquee class="news-scroll py-2 shadow " behavior="scroll" direction="right" onmouseover="this.stop();" onmouseout="this.start();" style="background-color: #768089;" >

                      <?php $__currentLoopData = $latests; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>


                          <a class="dot_link" href="" style="color: white; text-decoration:none!important;"><?php echo e(App::isLocale('ar') ? $latest->ar_title: $latest->en_title); ?></a> <span class="dot"></span>
                          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                      </marquee>
            </div>
        </div>
    </div>
</div>
</marquee>
</div>
            <main class="main-content" style="direction: rtl!important">
                <div class="fullwidth-block greet-section">
                    <div class="container">
                        <h2 class="section-title"><?php echo e(trans('app.about')); ?></h2>
                        <small class="section-subtitle"><?php echo e(trans('app.We offer a range of insurance services that meet the needs of all citizens')); ?></small>

                        <div class="row">
                            <div class="col-md-4">
                                <div class="feature">
                                    <i class="icon-phone-24"></i>
                                    <h3 class="feature-title"><?php echo e(trans('app.Vision')); ?></h3>
                                    <p><?php echo e(trans('app.Through')); ?></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="feature">
                                    <i class="icon-hotel"></i>
                                    <h3 class="feature-title"><?php echo e(trans('app.the message')); ?></h3>
                                    <p><?php echo e(trans('app.salvage')); ?></p>
                                </div>
                            </div>
                            <div class="col-md-4">
                                <div class="feature">
                                    <i class="icon-luggage"></i>
                                    <h3 class="feature-title"><?php echo e(trans('app.Objectives')); ?></h3>
                                    <p><?php echo e(trans('app.Traffic')); ?></p>
                                </div>
                            </div>
                            
                        </div> <!-- .row -->

                        <div class="text-center">
                          
                        </div>
                    </div> <!-- .container -->
                </div> <!-- .fullwidth-block -->

                <div class="fullwidth-block" data-bg-color="#f1f1f1">
                    <div class="container">
                        <h2 class="section-title">Our insurance offer</h2>
                        <small class="section-subtitle">Phasellus vel felis in nulla mollis posuere eget rutrum eros</small>

                        <div class="row">
                            <div class="col-md-3">
                                <div class="offer caption-top">
                                    <img src="<?php echo e(asset('website/dummy/offer-tall.jpg')); ?>" alt="offer 1">
                                    <div class="caption">
                                        <h3 class="offer-title">Massa augue</h3>
                                        <small>Conubia nostra per inceptos</small>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-9">
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="offer caption-bottom">
                                            <img src="<?php echo e(asset('website/dummy/offer-1.jpg')); ?>" alt="offer 2">
                                            <div class="caption">
                                                <h3 class="offer-title">Curabitur vehicula</h3>
                                                <small>Conubia nostra per inceptos</small>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-8">
                                        <div class="offer caption-bottom">
                                    <img src="<?php echo e(asset('website/dummy/offer-wide.jpg')); ?>" alt="offer 3">
                                    <div class="caption">
                                        <h3 class="offer-title">Vivamus rhoncus porttitor</h3>
                                        <small>Conubia nostra per inceptos</small>
                                    </div>
                                </div>
                                    </div>
                                </div>
                                <div class="row">
                                    <div class="col-md-4">
                                        <div class="offer caption-bottom">
                                            <img src="<?php echo e(asset('website/dummy/offer-2.jpg')); ?>" alt="offer 2">
                                            <div class="caption">
                                                <h3 class="offer-title">Curabitur vehicula</h3>
                                                <small>Conubia nostra per inceptos</small>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="offer caption-bottom">
                                            <img src="<?php echo e(asset('website/dummy/offer-3.jpg')); ?>" alt="offer 2">
                                            <div class="caption">
                                                <h3 class="offer-title">Curabitur vehicula</h3>
                                                <small>Conubia nostra per inceptos</small>  
                                            </div>
                                        </div>
                                    </div>
                                    <div class="col-md-4">
                                        <div class="offer caption-bottom">
                                            <img src="<?php echo e(asset('website/dummy/offer-4.jpg')); ?>" alt="offer 2">
                                            <div class="caption">
                                                <h3 class="offer-title">Curabitur vehicula</h3>
                                                <small>Conubia nostra per inceptos</small>  
                                            </div>
                                        </div>
                                    </div>
                                </div> <!-- .row -->
                            </div> <!-- .col-md-8 -->
                        </div> <!-- .row -->

                    </div> <!-- .container -->
                </div> <!-- .offer-section -->

                <div class="fullwidth-block">
                    <div class="container">
                        <h2 class="section-title"><?php echo e(trans('app.latest')); ?></h2>
                        <div class="row news-list">
                             <?php $__currentLoopData = $news_posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="news">
                                    <figure><img src="<?php echo e(route('getImage',$post->thumbnail)); ?>" alt=""></figure>
                                    <div class="date ltr nn"><?php echo e(App::isLocale('ar') ? $post->ar_title: $post->en_title); ?></div>
                                    <h2 class="entry-title ltr nn"><a href="<?php echo e(url('post/' . $post->slug)); ?>"><?php echo e(App::isLocale('ar') ? $post->ar_sub_title: $post->en_sub_title); ?></a></h2>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </div> <!-- .row -->
                    </div> <!-- .container -->
                </div> <!-- .latest-news-section -->

                <div class="fullwidth-block" data-bg-color="#0f75bd">
                    <div class="container">
                        <div class="testimonial-slider">
                            <ul class="slides">
                                <li>
                                    <blockquote><?php echo e(trans('app.contract')); ?><cite><?php echo e(trans('app.family protection insurance')); ?></cite></blockquote>
                                </li>
                                <li>
                                    <blockquote><?php echo e(trans('app.facilities')); ?><cite><?php echo e(trans('app.fire insurance')); ?></cite></blockquote>
                                </li>
                                <li>
                                    <blockquote><?php echo e(trans('app.institution')); ?> <cite><?php echo e(trans('app.Reinsurance aviation and ship hulls')); ?></cite></blockquote>
                                </li>
                            </ul>
                        </div>
                    </div> <!-- .container -->
                </div> <!-- .fullwidth-block -->

               <br>
               <br>
               <br>
<div class="container mt-3">
  <h2 style="text-align: center;"><?php echo e(trans('app.Frequently Askd Questions')); ?></h2>
<br>
  <div id="accordion">
     <?php $__currentLoopData = $questions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="card">
      <div class="card-header ltr">
        <a class="btn ltr" data-bs-toggle="collapse" href="#<?php echo e($question->icon); ?>">
<?php echo e(App::isLocale('ar') ? $question->ar_title: $question->en_title); ?>

        </a>
      </div>
      <div id="<?php echo e($question->icon); ?>" class="collapse show" data-bs-parent="#accordion">
        <div class="card-body ltr">
<?php echo App::isLocale('ar') ? $question->ar_details: $question->en_details; ?>

        </div>
      </div>
    </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

  </div>
  <br>
  <div class="ltr">
   <a  href="<?php echo e(url('question')); ?>"><?php echo e(trans('app.For Read More Plase click here')); ?>....</a>
</div>
</div>

                <div class="fullwidth-block">
                    <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3326.384000748498!2d36.297580885377066!3d33.517400453173245!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x1518e730265bdba5%3A0x95d4f4273fc7f51d!2z2KfZhNmF2KTYs9iz2Kkg2KfZhNi52KfZhdipINin2YTYs9mI2LHZitipINmE2YTYqtij2YXZitmG!5e0!3m2!1sar!2s!4v1656255716012!5m2!1sar!2s" width="1400" height="500" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
                </div>

            </main>

        </div>
    </body>
     <?php $__env->stopSection(); ?>




     
        

<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/index.blade.php ENDPATH**/ ?>