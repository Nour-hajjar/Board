<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
      <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>">
       
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
          <li class="menu-item"><a href="<?php echo e(url('category/news')); ?>"><?php echo e(trans('app.News')); ?></a></li>
            <li class="menu-item"><a href="<?php echo e(url('/category/regulations-and-laws')); ?>"><?php echo e(trans('app.Rules')); ?></a></li>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>
    <!-- Main Content -->
         <div class="fullwidth-block">
                    <div class="container">
               
                        <h2 class="section-title"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></h2>
                   
                        <div class="row news-list">
                            <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-md-4">
                                <div class="news">
                                    <figure><img src="<?php echo e(route('getImage',$post->thumbnail)); ?>" alt=""></figure>
                                    <div class="date ltr nn"><?php echo e(App::isLocale('ar') ? $post->ar_title: $post->en_title); ?></div>
                                    <h2 class="entry-title ltr nn"><a href="<?php echo e(url('post/' . $post->slug)); ?>"><?php echo e(App::isLocale('ar') ? $post->ar_sub_title: $post->en_sub_title); ?></a></h2>
                                </div>
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          
                        </div> <!-- .row -->
                    </div> <!-- .container -->
                </div> <!-- .latest-news-section -->
            <!-- Pager -->
                <div class="clearfix mt-4" style="padding: 10px!important; margin: 10px!important;">
                    <?php echo e($posts->links()); ?>

                </div>
            </div>

<?php $__env->stopSection(); ?>
<style >
    .post-image{
      /*  width: 300px;
        height: 250px;*/
       
    }
    .post-preview {
    left: 100px;
    right: 100px;

 }
 .d-inline-block {
    display: inline-block!important;
    margin-right: 80px;
}
.post-title{
    width: 420px;
    height: 140px;
}
</style>
<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/category.blade.php ENDPATH**/ ?>