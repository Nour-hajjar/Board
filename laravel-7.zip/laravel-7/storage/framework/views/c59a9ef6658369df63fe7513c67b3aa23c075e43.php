

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
      <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>"> 
  
        <div id="hero" class="hero overlay subpage-hero portfolio-hero">
        <div class="hero-content">
            <div class="hero-text">
                <h1><?php echo e(trans('app.verify')); ?></h1>
                <ol class="breadcrumb">
                  <!--   <li class="breadcrumb-item"><a href="#">الرئيسية</a></li>
                    <li class="breadcrumb-item active">حول</li> -->
                </ol>
            </div>
            <!-- /.hero-text -->
        </div>
        <!-- /.hero-content -->
    </div>
    <!-- /.hero -->


    <main id="main" class="site-main">

        <form action="/search" method="get">
    <div class="input-group dd" style=" width: 400px;padding: 40px 40px 40px 40px;">
        <input type="search" name="search" class="form-control" style="background-color: #ddd;">
        <br>
        <br>
        <br>
        <span class="input-group-prepend">
            <button type="submit" class="btn"  style="background-color: #0f75bd;
            color: white;"><?php echo e(trans('app.Search')); ?></button>
        </span>
    </div>
</form>
<br>
<br>
<br>

          <div itemprop="articleBody">
        <center>
<div class="table-responsive">
<p style="text-align: center;">&nbsp;</p>

<table class="table table-striped">
    <thead>
        <tr>
            <th style="text-align: center;"><?php echo e(trans('app.nname')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.namme')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.course')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.code')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.date')); ?></th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $master_infos; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $info): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td style="text-align: center;"><?php echo e(App::isLocale('ar') ? $info->ar_name: $info->en_name); ?></td>
            <td style="text-align: center;"><?php echo e(App::isLocale('ar') ? $info->name_a: $info->name); ?></td>
            <td style="text-align: center;"><?php echo e(App::isLocale('ar') ? $info->ar_course: $info->en_course); ?></td>
            <td style="text-align: center;"><?php echo e($info->code); ?></td>
            <td style="text-align: center;"><?php echo e($info->date); ?></td>
        </tr>
       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
</div>
</center>
    </div>

    </main>
    <!-- /#main -->
    <!-- /#main -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Pictures\INTBD\14-10\laravel-7\laravel-7\laravel-7\resources\views/website/information.blade.php ENDPATH**/ ?>