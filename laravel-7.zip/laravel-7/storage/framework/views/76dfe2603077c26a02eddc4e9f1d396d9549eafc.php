<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row">
            <div class="col">
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success alert-dismissible">
                        <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                        <?php echo e(Session('message')); ?>

                    </div>
                <?php endif; ?>

                    <?php if(Session::has('delete-message')): ?>
                        <div class="alert alert-danger alert-dismissible">
                            <button type="button" class="close" data-dismiss="alert" aria-hidden="true">x</button>
                            <?php echo e(Session('delete-message')); ?>

                        </div>
                    <?php endif; ?>
            </div>
        </div>

        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                       <?php echo e(trans('app.Category')); ?>

                     
                        <a href="<?php echo e(route('categories.create')); ?>" class="btn btn-sm btn-primary float-right nn"><?php echo e(trans('app.Add_New')); ?></a>
            
                    </div>

                    <div class="card-body">
                        <table class="table table-bordered mb-0">
                            <thead>
                            <tr>
                                <th style="text-align: center" scope="col" width="60">#</th>
                                <th style="text-align: center" scope="col"><?php echo e(trans('app.Title')); ?></th>
                                <th style="text-align: center" scope="col" width="200"><?php echo e(trans('app.creat')); ?></th>
                                <th style="text-align: center" scope="col" width="200"><?php echo e(trans('app.Action')); ?></th>
                            </tr>
                            </thead>

                            <tbody>
                         <?php $i = 1 ?>
                            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <tr>
                                       <td style="text-align: center" ><?php echo e($i++); ?></td>
                                    <td><?php echo e($category->name); ?></td>
                                      <td style="text-align: center" ><?php echo e($category->user->name); ?></td>
                                    <td>
                               <div class="row">
                                        <div class="col-sm-6"   >
                                            <a class="btn btn-sm  btn-success col-sm-12" href="<?php echo e(route('categories.show',$category->id)); ?>"><?php echo e(trans('app.show')); ?></a>
                                        </div>
                                        <div class="col-sm-6"  >
                                 
                                        <a href="<?php echo e(route('categories.edit', $category->id)); ?>"
                                           class="btn btn-sm btn-info col-sm-12"><?php echo e(trans('app.edit')); ?></a>
                               
                                             </div>
                                        <?php echo Form::open(['route' => ['categories.destroy', $category->id], 'method' => 'delete', 'style' => 'display:inline']); ?>

                                       <!--  <?php echo Form::submit(trans('app.delete'), ['class' => 'btn btn-sm btn-danger']); ?> -->
                                        <?php echo Form::close(); ?>

                                    </td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Noara\Desktop\INTBD\laravel-7\laravel-7\resources\views/admin/category/index.blade.php ENDPATH**/ ?>