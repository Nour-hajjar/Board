<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(trans('app.Category')); ?></div>

                    <div class="card-body">
                        <?php echo Form::open(['route' => 'categories.store']); ?>

                        <div class="form-group <?php if($errors->has('thumbnail')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.Thumbnail')); ?>

                            <?php echo Form::text('thumbnail', null, ['class' => 'form-control', 'placeholder' => 'Thumbnail']); ?>

                            <?php if($errors->has('thumbnail')): ?>
                                <span class="help-block"><?php echo $errors->first('thumbnail'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.name')); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block"><?php echo $errors->first('name'); ?></span><?php endif; ?>
                        </div>
                                  <div class="form-group <?php if($errors->has('name_a')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.name_a')); ?>

                            <?php echo Form::text('name_a', null, ['class' => 'form-control', 'placeholder' => 'name_a']); ?>

                            <?php if($errors->has('name_a')): ?>
                                <span class="help-block"><?php echo $errors->first('name_a'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label(trans('app.Publish')); ?>

                            <?php echo Form::select('is_published', [1 => 'Publish', 0 => 'Draft'], null, ['class' => 'form-control']); ?>

                        </div>

                        <?php echo Form::submit(trans('app.cs'),['class' => 'btn btn-sm btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Noara\Desktop\INTBD\laravel-7\laravel-7\resources\views/admin/category/create.blade.php ENDPATH**/ ?>