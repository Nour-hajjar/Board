<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">    <?php echo e(trans('app.Galleries')); ?></div>

                    <div class="card-body">
                        <?php echo Form::open(['route' => 'galleries.store', 'enctype' => 'multipart/form-data']); ?>


                        <div class="form-group <?php if($errors->has('image_url')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label('Image url', null, ['style' => 'display: block;']); ?>

                            <?php echo Form::file('image_url[]', ['multiple' => 'multiple']); ?>

                            <?php if($errors->has('image_url')): ?><span
                                    class="help-block"><?php echo $errors->first('image_url'); ?></span><?php endif; ?>
                        </div>

                        <?php echo Form::submit(trans('app.Create'),['class' => 'btn btn-sm btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Pictures\DB\laravel-7\resources\views/admin/gallery/create.blade.php ENDPATH**/ ?>