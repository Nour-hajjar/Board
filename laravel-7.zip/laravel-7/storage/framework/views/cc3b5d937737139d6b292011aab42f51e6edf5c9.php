<!DOCTYPE html>
<html>

<head>

      <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1.0,maximum-scale=1">
    <meta name="description" content="">
    <meta name="author" content="">
  
        

    <title><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></title>

    <!-- Bootstrap core CSS -->
      <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
    <link href="<?php echo e(asset('website/vendor/bootstrap/css/bootstrap.min.css')); ?>" rel="stylesheet">

    <!-- Custom fonts for this template -->

<link href="http://fonts.googleapis.com/css?family=Roboto+Condensed:300,400,700|" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('website/fonts/font-awesome.min.css')); ?>" rel="stylesheet" type="text/css">
        <link href="<?php echo e(asset('website/fonts/lineo-icon/style.css')); ?>" rel="stylesheet" type="text/css">

        <!-- Loading main css file -->
       
    <?php if(App::isLocale('ar')): ?>
     <link href="<?php echo e(asset('css/style1.css')); ?>" rel="stylesheet">
       <?php else: ?>
        <link rel="stylesheet" href="<?php echo e(asset('css/style.css')); ?>">
    <?php endif; ?>

</head>


<!-- Navigation -->
<!-- <nav class="navbar navbar-expand-lg navbar-light fixed-top" id="mainNav">
    <div class="container">
        <a class="navbar-brand" href="<?php echo e(url('/')); ?>">My WebSite</a>
        <button class="navbar-toggler navbar-toggler-right" type="button" data-toggle="collapse"
                data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false"
                aria-label="Toggle navigation">
            Menu
            <i class="fas fa-bars"></i>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
            <ul class="navbar-nav ml-auto">
                  <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(url('/')); ?>">Home</a>
                </li>
                <?php ($pages = getPages()); ?>
                <?php $__currentLoopData = $pages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                    <li class="nav-item">
                        <a class="nav-link" href="<?php echo e(url('page/' . $page->slug)); ?>"><?php echo e($page->title); ?></a>
                    </li>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
               
                <li class="nav-item">
                    <a class="nav-link" href="<?php echo e(route('contact.show')); ?>">Contact</a>
                </li>

                
            </ul>
        </div>
    </div>
</nav> -->


            
<body>
<?php echo $__env->yieldContent('content'); ?>



<!-- Footer -->
           <div class="site-footer">
                <div class="widget-area">
                    <div class="container dd">
                        <div class="row ltr">
                            <div class="col-xs-12 col-sm-4 col-md-2">
                                <div class="widget">
                                    <h3 class="widget-title"><?php echo e(trans('app.Contact')); ?></h3>
                                    <address> <?php echo e(trans('app.General Administration')); ?>

                                    </address>
                                    <a href="#"><?php echo e(trans('app.Numb')); ?>:011-9902</a>
                                    <a href="mailto:info@company.com">info@gmail.com</a>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-2">
                                <div class="widget">
                                    <h3 class="widget-title"></h3>
                                <!--     <ul class="no-bullet">
                                        <li><a href="#">About us</a></li>
                                        <li><a href="#">Infoline</a></li>
                                        <li><a href="#">Team</a></li>
                                        <li><a href="#">Join us</a></li>
                                        <li><a href="#">Cooperation</a></li>
                                    </ul> -->
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-2">
                                <div class="widget">
                                    <h3 class="widget-title"><?php echo e(trans('app.about')); ?></h3>
                                    <ul class="no-bullet">
                                        <li><a style="font-size: 16px!important;" href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                </li>
                                <br>
                                        <li><a style="font-size: 16px!important;" href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li>
                                        <br>
                                        <li><a style="font-size: 16px!important;" href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>
                                        <br>
                               <!--          <li><a style="font-size: 16px!important;"  href="<?php echo e(url('question')); ?>"><?php echo e(trans('app.Frequently Askd Questions')); ?></a></li> -->
                                       
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-2">
                                <div class="widget">
                                    <h3 class="widget-title"></h3>
                                    <!-- <ul class="no-bullet">
                                        <li><a href="#">Presentation</a></li>
                                        <li><a href="#">Testimonials</a></li>
                                        <li><a href="#">Examples</a></li>
                                        <li><a href="#">Our experts</a></li>
                                        <li><a href="#">Resources</a></li>
                                    </ul> -->
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-2">
                                <div class="widget">
                                    <h3 class="widget-title"><?php echo e(trans('app.latest')); ?></h3>
                                    <ul class="no-bullet">
                                    <li>
                                          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <a style="font-size: 16px!important;"href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a></li>
                                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                       <br>
                                    <li><a style="font-size: 16px!important;" href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                                    <br>
                                    <li><a style="font-size: 16px!important;"  href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                  
                                    
                                    </ul>
                                </div>
                            </div>
                            <div class="col-xs-12 col-sm-4 col-md-2">
                                <div class="widget">
                                    <h3 class="widget-title"></h3>
                                  <!--   <ul class="no-bullet">
                                        <li><a href="#">Sed imperdiet magna</a></li>
                                        <li><a href="#">Pellentesque molestie</a></li>
                                        <li><a href="#">Nulla luctus cursus</a></li>
                                        <li><a href="#">Ligula vel lacinia</a></li>
                                        <li><a href="#">Mauris scelerisque</a></li>
                                    </ul> -->
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <div class="bottom-footer">
                    <div class="container">
                        <nav class="footer-navigation">
                        <a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a>
                           <a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a>
                            <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                           <a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a>
                        </nav>
                          <div class="row">
                                <div class="col-md-6">
                             <h3 style="color: white;"><?php echo e(trans('app.Ministries in Syria')); ?></h3>
<a style="color: white; text-align: left;" href="http://www.pministry.gov.sy/"><?php echo e(trans('app.Presidency of the Council of Minister')); ?></a>
        <br>
          <br>
                    <a style="color: white;" href="http://www.syrianfinance.gov.sy/"><?php echo e(trans('app.Ministry of Finance')); ?></a>
                    <br>
                      <br>
                     <a style="color: white;" href="http://www.moj.gov.sy/"><?php echo e(trans('app.Ministry of Justice')); ?></a>
                </div>
                  <div class="col-md-6">
 <h4 style="color: white;"><?php echo e(trans('app.Insurance in Syria')); ?></h4>
                               <a style="color: white;" href="http://www.sisc.sy/"><?php echo e(trans('app.Insurance Supervisory Authority')); ?></a>
                                <br>
                                  <br>
                                            <a style="color: white;" href="http://www.sif-sy.sy/ar/node/1"><?php echo e(trans('app.Arab Union Reinsurance Company')); ?></a>
                                        </div>
                                    </div>
                                    <br>
                                      <br>
                        <div class="colophon">Copyright 2022 . Designed by Labtix. All rights reserved.</div>
                    </div>
                </div>
            </div>
        </div>
<!-- Bootstrap core JavaScript -->

   <script src="<?php echo e(asset('website/js/jquery-1.11.1.min.js')); ?>"></script>
        <script src="http://maps.google.com/maps/api/js?sensor=false&amp;language=en"></script>
        <script src="<?php echo e(asset('website/js/plugins.js')); ?>"></script>
        <script src="<?php echo e(asset('website/js/app.js')); ?>"></script>

</body>

</html>
<?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/template/master.blade.php ENDPATH**/ ?>