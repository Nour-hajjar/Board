

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
    <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>"> 
     
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                
          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
                               <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>




<br>
<br>
<br>

<div class="page-header">
                    <h2 itemprop="headline" style="text-align: center;">
      <?php echo e(trans('app.nnnnn')); ?>    </h2>
                                    </div>

<?php if(count($branchs) > 0): ?>
<div class="table-responsive">
<p style="text-align: center;">&nbsp;</p>
<table class="table table-striped">
        <thead>
        <tr>
            <th style="text-align: center;"><?php echo e(trans('app.Name')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.mobile1')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.mobile2')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.telephone1')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.telephone2')); ?></th>
              <th style="text-align: center;"><?php echo e(trans('app.fax1')); ?></th>
            <th style="text-align: center;"><?php echo e(trans('app.fax2')); ?></th>
              <th style="text-align: center;"><?php echo e(trans('app.address')); ?></th>
        </tr>
    </thead>
      
        <?php $__currentLoopData = $branchs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $branch): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <tbody>
            <tr>
            <td><?php echo e(App::isLocale('ar') ? $branch->ar_name: $branch->en_name); ?></td>
            <td><?php echo e($branch->mobile1); ?></td>
            <td><?php echo e($branch->mobile2); ?></td>
            <td><?php echo e($branch->telephone1); ?></td>
            <td><?php echo e($branch->telephone2); ?></td>
           <td><?php echo e($branch->fax1); ?></td>
            <td><?php echo e($branch->fax2); ?></td>
         <td><?php echo e(App::isLocale('ar') ? $branch->ar_address: $branch->en_address); ?></td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </tbody>
</table>
</div>
</div>
</body>
<?php else: ?>
    <p> You have no entries</p>
<?php endif; ?>
<br>
<br>
<br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/search.blade.php ENDPATH**/ ?>