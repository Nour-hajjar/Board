

<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
      <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>">

  
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                
          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
                               <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>
    <h2 style="color: #0f75bd; text-align: center;" class="section-title mb-3 pt-3" data-aos="fade-up" data-aos-delay="">
<?php echo e(trans('app.Send Complaint')); ?></h2>

</div>
    <!-- Main Content -->
    <div class="section-headline text-center">
              <br><br>
                <?php if(Session::has('message')): ?>
                    <div class="alert alert-success">
                        <?php echo e(Session('message')); ?>

                    </div>
                <?php endif; ?>
        
            </div>
      <div class="container">
      <form method="POST" action="/complaintaction" class="rtl">


        <?php echo e(csrf_field()); ?>


       <div>
         <div class="form-group floating-label-form-group controls">
          <div class="row">

            <!-- Start Google Map -->

          
            <div class="col-md-12" style="direction: rtl!important;">
               <div class="row">
                   <div class="col-md-6">

                   <div class="control-group" >
                <div class="form-group ltr">
                
                        <label  style="color: #0f75bd; font-weight: bold; "><?php echo e(trans('app.Name')); ?></label>
                        <input type="text" name="name" class="form-control" placeholder="<?php echo e(trans('app.Name')); ?>" id="name" required
                               data-validation-required-message="Please enter your name.">
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
           
          
                    <div class="control-group ltr">
                    <div class="form-group floating-label-form-group controls">
                         <label style="color:#0f75bd; font-weight: bold;"><?php echo e(trans('app.email')); ?></label>
                        <input type="email" name="email" class="form-control" placeholder="<?php echo e(trans('app.email')); ?>" id="email" required
                               data-validation-required-message="Please enter your email address.">
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
                     <div class="control-group ltr">
                     <div class="form-group ">
                         <label style="color: #0f75bd;; font-weight: bold;"><?php echo e(trans('app.Phone')); ?></label>
                        <input type="text" name="phone" class="form-control" placeholder="<?php echo e(trans('app.Phone')); ?>" id="phone" required
                               data-validation-required-message="Please enter your mobile phone.">
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
              </div>

                                            <div class="col-md-6">

                   <div class="control-group" >
                <div class="form-group ltr">
                
                        <label  style="color: #0f75bd; font-weight: bold; "><?php echo e(trans('app.national')); ?></label>
                        <input type="text" name="national" class="form-control" placeholder="<?php echo e(trans('app.national')); ?>" id="national" required
                               data-validation-required-message="Please enter your name.">
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
               
                 <div class="control-group ltr">
                    <div class="form-group floating-label-form-group controls">
                         <label style="color: #0f75bd; font-weight: bold;"><?php echo e(trans('app.message')); ?></label>
                        <textarea rows="2" name="message" class="form-control" placeholder="<?php echo e(trans('app.message')); ?>" id="message" required
                               data-validation-required-message="Please enter your message address."></textarea>
                        <p class="help-block text-danger"></p>
                    </div>
                </div>
              </div>
            </div>
          </div>
   
                 <div class="ltr">
<a  href="https://www.facebook.com/pages/category/Insurance-company/%D8%A7%D9%84%D8%AA%D8%A3%D9%85%D9%8A%D9%86-%D8%A7%D9%84%D8%B5%D8%AD%D9%8A-%D9%81%D9%8A-%D8%A7%D9%84%D8%B3%D9%88%D8%B1%D9%8A%D8%A9-%D9%84%D9%84%D8%AA%D8%A3%D9%85%D9%8A%D9%86-102689374456839/"  target="_blank"><?php echo e(trans('app.For more information about complaints, please visit the complaints Facebook page')); ?>....</a>
</div>
    </div>
  </div>
</div>
</div>

             
     <div class="text-center" ><button style="color:white!important; " class="text" type="submit" ><?php echo e(trans('app.Send Complaint')); ?></button></div>
         <br>  
</form>
            
    </div>

<style>
 


  input[type=text], select, textarea {
  width: 100%;
  padding: 12px;
  border: 1px solid #ccc;
  border-radius: 4px;
  box-sizing: border-box;
  margin-top: 6px;
  margin-bottom: 16px;
  resize: vertical;
}

input[type=submit] {
  background-color: #0085a1;
  color: white;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;

}

input[type=submit]:hover {
  background-color: #0085a1;
}
 
.text{
    background: #768089!important;
    border: 0;
    border-radius: 50px;
    padding: 10px 24px;
    color: #fff;

   text-align: center;
   font-weight: bold!important;
   font-size: 20px!important;
    
  }
  

</style>             
<?php $__env->stopSection(); ?>

<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/complaint.blade.php ENDPATH**/ ?>