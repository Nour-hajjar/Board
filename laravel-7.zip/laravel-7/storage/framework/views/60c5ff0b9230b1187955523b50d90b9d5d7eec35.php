<?php $__env->startSection('stylesheet'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(trans('app.info')); ?></div>

                    <div class="card-body">
                        <?php echo Form::open(['route' => 'infos.store']); ?>

                        <div class="form-group <?php if($errors->has('en_name')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_name')); ?>

                            <?php echo Form::text('en_name', null, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

                            <?php if($errors->has('en_name')): ?>
                                <span class="help-block"><?php echo $errors->first('en_name'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('ar_name')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_name')); ?>

                            <?php echo Form::text('ar_name', null, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

                            <?php if($errors->has('ar_name')): ?>
                                <span class="help-block"><?php echo $errors->first('ar_name'); ?></span><?php endif; ?>
                        </div>
                                   <div class="form-group <?php if($errors->has('name')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.namee')); ?>

                            <?php echo Form::text('name', null, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

                            <?php if($errors->has('name')): ?>
                                <span class="help-block"><?php echo $errors->first('name'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('name_a')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.namee_a')); ?>

                            <?php echo Form::text('name_a', null, ['class' => 'form-control', 'placeholder' => 'Name']); ?>

                            <?php if($errors->has('name_a')): ?>
                                <span class="help-block"><?php echo $errors->first('name_a'); ?></span><?php endif; ?>
                        </div>
                                <div class="form-group <?php if($errors->has('en_course')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_course')); ?>

                            <?php echo Form::text('en_course', null, ['class' => 'form-control', 'placeholder' => 'Course']); ?>

                            <?php if($errors->has('en_course')): ?>
                                <span class="help-block"><?php echo $errors->first('en_course'); ?></span><?php endif; ?>
                        </div>
            <div class="form-group <?php if($errors->has('ar_course')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_course')); ?>

                            <?php echo Form::text('ar_course', null, ['class' => 'form-control', 'placeholder' => 'Course']); ?>

                            <?php if($errors->has('ar_course')): ?>
                                <span class="help-block"><?php echo $errors->first('ar_course'); ?></span><?php endif; ?>
                        </div>
                                    <div class="form-group <?php if($errors->has('code')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.code')); ?>

                            <?php echo Form::text('code', null, ['class' => 'form-control', 'placeholder' => 'Code']); ?>

                            <?php if($errors->has('code')): ?>
                                <span class="help-block"><?php echo $errors->first('code'); ?></span><?php endif; ?>
                        </div>
                                    <div class="form-group <?php if($errors->has('date')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.date')); ?>

                            <?php echo Form::text('date', null, ['class' => 'form-control', 'placeholder' => 'date']); ?>

                            <?php if($errors->has('date')): ?>
                                <span class="help-block"><?php echo $errors->first('date'); ?></span><?php endif; ?>
                        </div>
   


                        <?php echo Form::submit(trans('app.Create'),['class' => 'btn btn-sm btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"
            integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Noara\Desktop\INTBD\laravel-7\laravel-7\resources\views/admin/info/create.blade.php ENDPATH**/ ?>