<?php $__env->startSection('stylesheet'); ?>
    <link href="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/css/select2.min.css" rel="stylesheet"/>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header"><?php echo e(trans('app.Latest_Post')); ?></div>

                    <div class="card-body">
                        <?php echo Form::open(['route' => 'posts.store']); ?>

                        <div class="form-group <?php if($errors->has('thumbnail')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.Thumbnail')); ?>

                            <?php echo Form::text('thumbnail', null, ['class' => 'form-control', 'placeholder' => 'Thumbnail']); ?>

                            <?php if($errors->has('thumbnail')): ?>
                                <span class="help-block"><?php echo $errors->first('thumbnail'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('en_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_title')); ?>

                            <?php echo Form::text('en_title', null, ['class' => 'form-control', 'placeholder' => 'en_title']); ?>

                            <?php if($errors->has('en_title')): ?>
                                <span class="help-block"><?php echo $errors->first('en_title'); ?></span><?php endif; ?>
                        </div>
                                   <div class="form-group <?php if($errors->has('ar_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_title')); ?>

                            <?php echo Form::text('ar_title', null, ['class' => 'form-control', 'placeholder' => 'ar_title']); ?>

                            <?php if($errors->has('ar_title')): ?>
                                <span class="help-block"><?php echo $errors->first('ar_title'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('en_sub_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_sub_title')); ?>

                            <?php echo Form::text('en_sub_title', null, ['class' => 'form-control', 'placeholder' => 'Sub Title']); ?>

                            <?php if($errors->has('en_sub_title')): ?>
                                <span class="help-block"><?php echo $errors->first('en_sub_title'); ?></span><?php endif; ?>
                        </div>
                                <div class="form-group <?php if($errors->has('ar_sub_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_sub_title')); ?>

                            <?php echo Form::text('ar_sub_title', null, ['class' => 'form-control', 'placeholder' => 'ar_sub_title']); ?>

                            <?php if($errors->has('ar_sub_title')): ?>
                                <span class="help-block"><?php echo $errors->first('ar_sub_title'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('en_details')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_details')); ?>

                            <?php echo Form::textarea('en_details', null, ['class' => 'form-control', 'placeholder' => 'en_details']); ?>

                            <?php if($errors->has('en_details')): ?>
                                <span class="help-block"><?php echo $errors->first('en_details'); ?></span><?php endif; ?>
                        </div>
                               <div class="form-group <?php if($errors->has('ar_details')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_details')); ?>

                            <?php echo Form::textarea('ar_details', null, ['class' => 'form-control', 'placeholder' => 'ar_details']); ?>

                            <?php if($errors->has('ar_details')): ?>
                                <span class="help-block"><?php echo $errors->first('ar_details'); ?></span><?php endif; ?>
                        </div>

                        <div class="form-group <?php if($errors->has('category_id')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.Category')); ?>

                            <?php echo Form::select('category_id[]', $categories, null, ['class' => 'form-control', 'id' => 'category_id', 'multiple' => 'multiple']); ?>

                            <?php if($errors->has('category_id')): ?>
                                <span class="help-block"><?php echo $errors->first('category_id'); ?></span>
                            <?php endif; ?>
                        </div>

                        <div class="form-group">
                            <?php echo Form::label(trans('app.Publish')); ?>

                            <?php echo Form::select('is_published', [1 => 'Publish', 0 => 'Draft'], null, ['class' => 'form-control']); ?>

                        </div>

                        <?php echo Form::submit(trans('app.Create'),['class' => 'btn btn-sm btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"
            integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>

       <script>
        $(document).ready(function () {
            CKEDITOR.replace('en_details', {
            removePlugins: 'sourcearea'
        });
            CKEDITOR.replace('ar_details', {
            removePlugins: 'sourcearea'
        });


            $('#category_id').select2({
                placeholder: "Select categories"
            });
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/admin/post/create.blade.php ENDPATH**/ ?>