

<?php $__env->startSection('content'); ?>
    <div class="container">
        <div class="row justify-content-center">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header">
                        <?php echo e(trans('app.latest') .': '); ?>

                       
            <a class="btn btn-sm btn-primary float-right col-sm-2" href="<?php echo e(route('latests.index')); ?>"><?php echo e(trans('app.Back')); ?> </a>
                        
                    </div>

                    <div class="card-body">
                        <?php echo Form::open(['route' => 'latests.store']); ?>

    
                

                        <div class="form-group <?php if($errors->has('en_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.en_title')); ?>

                            <?php echo Form::text('en_title', null, ['class' => 'form-control', 'placeholder' => 'en_title']); ?>

                            <?php if($errors->has('en_title')): ?>
                                <span class="help-block " style="color:red;"><?php echo $errors->first('en_title'); ?></span><?php endif; ?>
                        </div>
                               <div class="form-group <?php if($errors->has('ar_title')): ?> has-error <?php endif; ?>">
                            <?php echo Form::label(trans('app.ar_title')); ?>

                            <?php echo Form::text('ar_title', null, ['class' => 'form-control', 'placeholder' => 'ar_title']); ?>

                            <?php if($errors->has('ar_title')): ?>
                              <span class="help-block " style="color:red;"><?php echo $errors->first('ar_title'); ?></span><?php endif; ?>
                        </div>

                      
                        <?php echo Form::submit(trans('app.cs'),['class' => 'btn btn-sm btn-primary']); ?>

                        <?php echo Form::close(); ?>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('javascript'); ?>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"
            integrity="sha256-9/aliU8dGd2tb6OSsuzixeV4y/faTqgFtohetphbbj0=" crossorigin="anonymous"></script>
    <script src="https://cdn.ckeditor.com/4.14.0/standard/ckeditor.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/select2@4.0.13/dist/js/select2.min.js"></script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/admin/latest/create.blade.php ENDPATH**/ ?>