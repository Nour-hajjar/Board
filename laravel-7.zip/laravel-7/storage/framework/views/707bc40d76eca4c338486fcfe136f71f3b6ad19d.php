<?php $__env->startSection('content'); ?>
    <!-- Page Header -->
      <body dir="<?php echo e((App::isLocale('ar') ? 'rtl' : 'ltr')); ?>"> 
  
        <div id="site-content" >
              <header class="site-header" >
                <div class="top-header">
                    <div class="container">
                        <a href="=" id="branding">
                            <img src="<?php echo e(asset('website/img/logo.png')); ?>" alt="Company Name" class="logo" style="height: 70px;">
                            <div class="logo-text">
                                <h1 class="site-title"><?php echo e(trans('app.Syrian General Insurance Corporation')); ?></h1>
                                <small class="description"></small>
                            </div>
                        </a> <!-- #branding -->
                    
                        <div class="right-section pull-right" >
                            <a href="#" class="phone"><img src="<?php echo e(asset('website/images/icon-phone.png')); ?>" class="icon">011-9902</a>
                    
                         <a href="#" class="phone"><img src="<?php echo e(asset('website/images/mail.jpg')); ?>" style="height: 40px;" class="icon">info@gmail.com</a>
                           <a href="#" class="phone"><img src="" style="height: 40px;" class="icon"></a>
                         <br>
                           <a href="<?php echo e(url('complaint')); ?>" class="phone"><?php echo e(trans('app.opinions')); ?></a> </div>
                    </div> <!-- .container -->
                </div> <!-- .top-header -->

                
                <div class="bottom-header dd"  >
                    <div class="container" >
                        <div class="main-navigation" >
                            <button type="button" class="menu-toggle"><i class="fa fa-bars"></i></button>
                            <ul class="menu"  >
                                <li class="menu-item"><a  href="<?php echo e(url('/')); ?>"><?php echo e(trans('app.Home')); ?></a></li>
                                  <li class="menu-item"><a href="<?php echo e(url('about')); ?>"><?php echo e(trans('app.about')); ?></a></li>
                                <li class="menu-item"><a href="<?php echo e(url('complaint')); ?>"><?php echo e(trans('app.Complainant')); ?></a></li>
                                
          <?php $__currentLoopData = $master_categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <li class="menu-item">
                               <a  href="<?php echo e(url('category/' . $category->slug)); ?>"><?php echo e(App::isLocale('ar') ? $category->name_a: $category->name); ?></a>
                              </li>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                               
       
         

        <li class="menu-item"><a href="<?php echo e(url('mainn')); ?>"><?php echo e(trans('app.insurancee')); ?></a></li>   
          <li class="menu-item"><a href="<?php echo e(url('branch')); ?>"><?php echo e(trans('app.Agents')); ?></a></li> 
  <li class="menu-item"><a href="<?php echo e(url('chart')); ?>"><?php echo e(trans('app.org')); ?></a></li>  
 <li class="menu-item"><a href="<?php echo e(url('contact')); ?>"><?php echo e(trans('app.Contact')); ?></a></li>
                     <li><a class="menu-item" href="<?php echo e(url('/lang/en')); ?>"><?php echo e(trans('app.En')); ?></a></li>
              <li><a class="menu-item" href="<?php echo e(url('/lang/ar')); ?>"><?php echo e(trans('app.Ar')); ?></a></li>
                            </ul> <!-- .menu -->
                        </div> <!-- .main-navigation -->
                        
                        <div class="social-links">
                            <a href="https://ar-ar.facebook.com/sicSYR/"><i class="fa fa-facebook"></i></a>
                            <a href="https://twitter.com/sicSYR"><i class="fa fa-twitter"></i></a>
                            <a href="https://plus.google.com/+sicSYR"><i class="fa fa-google-plus"></i></a>
                            <a href="https://www.youtube.com/sicSYR"><i class="fa fa-pinterest"></i></a>
                        </div>
                        
                        <div class="mobile-navigation"></div>
                    </div>
                </div>
                
            </header>
    <!-- Post Content -->
<main class="main-content">
               

                <div class="page">
                    <div class="container">
                        <h3 class="entry-title ltr"><?php echo e(App::isLocale('ar') ? $post->ar_title: $post->en_title); ?></h3>
                        <div class="ltr">
                        <p ><?php echo App::isLocale('ar') ? $post->ar_details: $post->en_details; ?></p>
                    </div>

</div>
</div>
</main>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('website.template.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\n.hajjar\Desktop\laravel-7\laravel-7\resources\views/website/post.blade.php ENDPATH**/ ?>